package com.aditya.demoMysqlRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMysqlRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
